#!/bin/bash

# Caddy 自动安装脚本
# 基于原始脚本修改，支持交互式配置

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 错误处理
error() {
    echo -e "\n${red}输入错误!${none}\n"
}

# 暂停函数
pause() {
    read -rsp "$(echo -e "按${cyan}Enter${none}键继续...或按${cyan}Ctrl+C${none}取消")" -d $'\n'
    echo
}

# 获取本机IP
get_local_ip() {
    # 尝试IPv4
    local ipv4=$(curl -4s --connect-timeout 5 https://www.cloudflare.com/cdn-cgi/trace 2>/dev/null | grep ip= | sed -e "s/ip=//g")
    if [[ -n "$ipv4" ]]; then
        echo "$ipv4"
        return
    fi
    
    # 尝试IPv6
    local ipv6=$(curl -6s --connect-timeout 5 https://www.cloudflare.com/cdn-cgi/trace 2>/dev/null | grep ip= | sed -e "s/ip=//g")
    if [[ -n "$ipv6" ]]; then
        echo "$ipv6"
        return
    fi
    
    # 备用方法
    local backup_ip=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null)
    echo "${backup_ip:-unknown}"
}

# 验证域名解析
validate_domain() {
    local domain=$1
    local local_ip=$2
    
    echo "正在验证域名解析..."
    
    # 获取域名解析的IP
    local domain_ip=$(dig +short "$domain" @8.8.8.8 2>/dev/null | tail -n1)
    
    if [[ -z "$domain_ip" ]]; then
        echo -e "${yellow}警告: 无法解析域名 $domain${none}"
        return 1
    fi
    
    if [[ "$domain_ip" != "$local_ip" ]]; then
        echo -e "${yellow}警告: 域名 $domain 解析到 $domain_ip，但本机IP是 $local_ip${none}"
        return 1
    fi
    
    echo -e "${green}域名解析验证通过${none}"
    return 0
}

# 主安装函数
install_caddy() {
    echo -e "${yellow}开始安装 Caddy 代理服务...${none}"
    echo "================================================================"
    
    # 获取本机IP
    local_ip=$(get_local_ip)
    echo -e "检测到本机IP: ${cyan}$local_ip${none}"
    echo
    
    # 默认配置
    naive_user="haoge"
    naive_pass="123456789kt"
    naive_port=443
    naive_email="e16d9cb045d7@gmail.com"
    
    # 域名输入
    while :; do
        echo -e "请输入一个 ${magenta}正确的域名${none}"
        read -p "(例如: mydomain.com): " naive_domain
        [ -z "$naive_domain" ] && error && continue
        
        # 简单的域名格式验证
        if [[ ! "$naive_domain" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]$ ]]; then
            echo -e "${red}域名格式不正确${none}"
            continue
        fi
        
        echo
        echo -e "$yellow 你的域名 = $cyan$naive_domain$none"
        echo "----------------------------------------------------------------"
        break
    done
    
    # 端口输入
    while :; do
        echo -e "请输入 ${yellow}端口${none} [${magenta}1-65535${none}], 不能选择 ${magenta}80${none}端口"
        read -p "$(echo -e "(默认端口: ${cyan}${naive_port}${none}):")" port_input
        [ -z "$port_input" ] && port_input=$naive_port
        
        case $port_input in
            80)
                echo -e "${red}不能选择 80 端口${none}"
                error
                ;;
            [1-9]|[1-9][0-9]|[1-9][0-9][0-9]|[1-9][0-9][0-9][0-9]|[1-5][0-9][0-9][0-9][0-9]|6[0-4][0-9][0-9][0-9]|65[0-4][0-9][0-9]|655[0-3][0-5])
                naive_port=$port_input
                echo
                echo -e "$yellow 端口 = $cyan$naive_port$none"
                echo "----------------------------------------------------------------"
                break
                ;;
            *)
                error
                ;;
        esac
    done
    
    # 伪装网址输入
    while :; do
        echo -e "请输入一个 ${magenta}正确的域名作为伪装网址${none}"
        read -p "(例如: bing.com): " naive_fakeweb
        [ -z "$naive_fakeweb" ] && error && continue
        
        echo
        echo -e "$yellow 伪装网址 = $cyan$naive_fakeweb$none"
        echo "----------------------------------------------------------------"
        break
    done
    
    # 验证域名解析（可选）
    echo -e "${yellow}验证域名解析...${none}"
    if ! validate_domain "$naive_domain" "$local_ip"; then
        echo -e "${yellow}是否继续安装? (y/N)${none}"
        read -p ": " continue_install
        if [[ "$continue_install" != "y" && "$continue_install" != "Y" ]]; then
            echo -e "${red}安装已取消${none}"
            exit 1
        fi
    fi
    
    echo
    echo -e "${yellow}开始系统配置...${none}"
    echo "----------------------------------------------------------------"
    
    # 更新系统并安装必要软件
    echo "更新系统软件包..."
    apt update -qq
    apt install -y sudo curl wget git jq qrencode
    
    # 停止可能运行的caddy服务
    systemctl stop caddy 2>/dev/null || true
    
    # 确定当前caddy程序的位置
# 优先查找 /root/caddy，然后是其他位置
CURRENT_CADDY=""
for path in "/root/caddy" "./caddy" "$(pwd)/caddy" "/root/caddy-"*"-linux-amd64" "./caddy-"*"-linux-amd64" "$(pwd)/caddy-"*"-linux-amd64"; do
    if [[ -f "$path" && -x "$path" ]]; then
        CURRENT_CADDY="$path"
        break
    fi
done

if [[ -z "$CURRENT_CADDY" ]]; then
    echo -e "${red}错误: 找不到 caddy 可执行文件${none}"
    echo "请确保 caddy 文件存在于以下位置之一："
    echo "  /root/caddy"
    echo "  ./caddy"
    echo -e "${yellow}⚠️  您也可以手动运行: sudo /etc/caddy/install.sh${none}"
    exit 1
fi
    
    echo -e "找到 Caddy 程序: ${cyan}$CURRENT_CADDY${none}"
    
    # 复制caddy到系统目录
    echo "天神之神正在自我部署..."
    cp "$CURRENT_CADDY" /usr/bin/caddy
    chmod +x /usr/bin/caddy
    
     
# 删除原始文件（避免重复占用空间）
if [[ -f /usr/bin/caddy ]] && /usr/bin/caddy version >/dev/null 2>&1; then
    echo "验证安装成功，删除原始文件..."
    rm -f "$CURRENT_CADDY"
    echo -e "${green}原始文件已清理${none}"
else
    echo -e "${yellow}警告: 无法验证安装，保留原始文件${none}"
fi

    # 创建caddy用户和组
    echo "创建系统用户..."
    if ! getent group caddy >/dev/null; then
        groupadd --system caddy
    fi
    
    if ! getent passwd caddy >/dev/null; then
        useradd --system \
            --gid caddy \
            --create-home \
            --home-dir /var/lib/caddy \
            --shell /usr/sbin/nologin \
            --comment "Caddy web server" \
            caddy
    fi
    
    # 创建Caddyfile（注意这里用的是 << EOF，允许变量替换）
    echo "生成配置文件..."
    if [ ! -d /etc/caddy ]; then
        mkdir -p /etc/caddy
    fi
    
    cat > /etc/caddy/Caddyfile << EOF
# _naive_config_begin_
{
    order forward_proxy before file_server
}
:${naive_port}, ${naive_domain} {
    tls ${naive_email}
    route {
        forward_proxy {
            basic_auth ${naive_user} ${naive_pass}
            hide_ip
            hide_via
            probe_resistance
        }
        reverse_proxy ${naive_fakeweb} {
            header_up Host {upstream_hostport}
        }
    }
}
# _naive_config_end_
EOF
    
    # 创建systemd服务文件（注意这里用的是 << 'EOF'，不允许变量替换）
    if [[ ! -f /etc/systemd/system/caddy.service ]]; then
        echo "创建系统服务..."
        cat > /etc/systemd/system/caddy.service << 'EOF'
[Unit]
Description=Caddy
Documentation=https://caddyserver.com/docs/
After=network.target network-online.target
Requires=network-online.target

[Service]
User=caddy
Group=caddy
ExecStartPre=/bin/sh -c '/bin/chown -R caddy:caddy /etc/caddy/databases && /usr/bin/find /etc/caddy/databases -type f -exec chmod 600 {} \;'
ExecStart=/usr/bin/caddy run --environ --config /etc/caddy/Caddyfile
ExecReload=/usr/bin/caddy reload --config /etc/caddy/Caddyfile
ExecStop=/usr/bin/caddy stop
TimeoutStopSec=10s
Restart=on-failure
RestartSec=5s
PrivateTmp=true
LimitNOFILE=1048576
LimitNPROC=512
AmbientCapabilities=CAP_NET_BIND_SERVICE
Environment=HOME=/var/lib/caddy
Environment=XDG_DATA_HOME=/var/lib/caddy/.local/share
Environment=XDG_CONFIG_HOME=/var/lib/caddy/.config
Environment=CADDY_CLUSTERING=true

[Install]
WantedBy=multi-user.target
EOF
    fi
    
    chmod +x /etc/systemd/system/caddy.service
    
   # 设置权限
echo "设置文件权限..."
chown -R caddy:caddy /etc/caddy/
chmod 755 /etc/caddy/

# 确保数据库目录存在并设置安全权限
if [[ ! -d "/etc/caddy/databases" ]]; then
    mkdir -p /etc/caddy/databases
    chown caddy:caddy /etc/caddy/databases
fi
chmod 700 /etc/caddy/databases

# 如果数据库文件已存在，设置安全权限
if ls /etc/caddy/databases/*.hotyi >/dev/null 2>&1; then
    chmod 600 /etc/caddy/databases/*.hotyi
    echo "数据库文件权限已设置为 600"
fi

# 设置配置文件权限
chmod 644 /etc/caddy/Caddyfile 2>/dev/null || true
chmod 644 /etc/caddy/config.yaml 2>/dev/null || true
    
    # 启动服务
    echo "启动 Caddy 服务..."
    systemctl daemon-reload
    systemctl enable caddy
    systemctl start caddy
    
    # 等待服务启动
    sleep 3
    
    # 检查服务状态
    if systemctl is-active --quiet caddy; then
        echo -e "${green}Caddy 服务启动成功！${none}"
    else
        echo -e "${red}Caddy 服务启动失败，请检查配置${none}"
        echo "查看详细错误信息："
        systemctl status caddy --no-pager
        echo "查看日志："
        journalctl -u caddy --no-pager -n 20
        exit 1
    fi
    
    # 生成连接信息
    echo
    echo -e "${yellow}安装完成！配置信息如下：${none}"
    echo "================================================================"
    echo -e "域名: ${cyan}${naive_domain}${none}"
    echo -e "端口: ${cyan}${naive_port}${none}"
    echo -e "用户名: ${cyan}${naive_user}${none}"
    echo -e "密码: ${cyan}${naive_pass}${none}"
    echo -e "伪装网址: ${cyan}${naive_fakeweb}${none}"
    echo "================================================================"
    
    # 生成代理URL
    naive_url="https://$(echo -n "${naive_user}:${naive_pass}@${naive_domain}:${naive_port}" | base64 -w 0)"
    echo -e "${green}代理连接URL:${none}"
    echo -e "${cyan}${naive_url}${none}"
    echo
    
    # 生成二维码
    echo "二维码："
    qrencode -t UTF8 "$naive_url" 2>/dev/null || echo "无法生成二维码（qrencode未安装）"
    
    # 保存配置信息
    cat > /root/caddy_info.txt << EOF
Caddy 代理配置信息
安装时间: $(date)
域名: ${naive_domain}
端口: ${naive_port}
用户名: ${naive_user}
密码: ${naive_pass}
伪装网址: ${naive_fakeweb}
代理URL: ${naive_url}
EOF
    
    echo
    echo "================================================================"
    echo -e "${yellow}重要提醒：${none}"
    echo -e "1. 管理界面: ${cyan}https://${naive_domain}/admin/login${none}"
    echo -e "   ${yellow}⚠️  请先添加用户后使用${none}"
    echo -e "2. 超级管理员: ${cyan}https://${naive_domain}/admin/rootlogin${none}"
    echo -e  "${red}超级管理员（root)密码: ${yellow}12345678kt${none} ${red}(请立即登录修改密码!)${none}"
    echo -e "3. 配置信息已保存到: ${cyan}/root/caddy_info.txt${none}"
    echo -e "4. 请确保防火墙已开放端口 ${cyan}${naive_port}${none}"
    echo "================================================================"
    echo -e "${green}安装完成！${none}"
}

# 检查是否以root权限运行
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 主程序
echo -e "${green}Caddy 代理服务安装向导${none}"
echo "================================================================"
echo "此脚本将帮助您配置和安装 Caddy 代理服务"
echo "================================================================"
echo

# 确认安装
read -p "$(echo -e "是否继续安装? (${green}y${none}/${red}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${yellow}安装已取消${none}"
    exit 0
fi

# 开始安装
install_caddy