#!/bin/bash

# 天神之眼数据备份脚本

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 错误处理
error_exit() {
    log "${red}❌ $1${none}"
    exit 1
}



# 主备份函数
backup_caddy_data() {
    echo -e "${yellow}🗄️  开始备份天神之眼数据...${none}"
    echo "================================================================"
    
    # 检查源目录是否存在
    if [[ ! -d "/etc/caddy" ]]; then
        error_exit "天神之眼配置目录不存在"
    fi
    
    # 生成备份文件名（包含日期时间）
    local backup_time=$(date '+%Y%m%d_%H%M%S')
    local backup_file="/root/caddy_data_backup_${backup_time}.zip"
    
    log "备份目标: ${cyan}$backup_file${none}"
    
    # 检查zip命令是否可用
    if ! command -v zip >/dev/null 2>&1; then
        log "安装zip工具..."
        apt update -qq && apt install -y zip || error_exit "无法安装zip工具"
    fi
    
    # 定义需要备份的文件列表
    local files_to_backup=(
        "/etc/caddy/databases/log_database.hotyi"
        "/etc/caddy/databases/user_database.hotyi"
        "/etc/caddy/Caddyfile"
        "/etc/caddy/config.yaml"
    )
    
    # 检查文件是否存在并创建临时文件列表
    local existing_files=()
    local missing_files=()
    
    for file in "${files_to_backup[@]}"; do
        if [[ -f "$file" ]]; then
            existing_files+=("$file")
            log "✓ 找到文件: ${file#/etc/caddy/}"
        else
            missing_files+=("$file")
            log "⚠️  文件不存在: ${file#/etc/caddy/}"
        fi
    done
    
    # 如果没有任何文件存在，报错退出
    if [[ ${#existing_files[@]} -eq 0 ]]; then
        error_exit "没有找到任何需要备份的文件"
    fi
    
    # 显示备份计划
    echo -e "${yellow}将备份以下文件:${none}"
    for file in "${existing_files[@]}"; do
        echo "  - ${file#/etc/caddy/}"
    done
    
    if [[ ${#missing_files[@]} -gt 0 ]]; then
        echo -e "${yellow}以下文件不存在，将跳过:${none}"
        for file in "${missing_files[@]}"; do
            echo "  - ${file#/etc/caddy/}"
        done
    fi
    echo
    
    # 创建备份
    log "正在备份指定文件..."

    #保存当前目录并切换
    local original_dir=$(pwd)
    if ! cd /etc/caddy 2>/dev/null; then
        error_exit "无法访问 /etc/caddy 目录"
    fi
    
    # 使用相对路径创建zip文件，保持目录结构
    local zip_files=()
    for file in "${existing_files[@]}"; do
        # 转换为相对于 /etc/caddy 的路径
        local relative_path="${file#/etc/caddy/}"
        zip_files+=("$relative_path")
    done
    
    if zip -r "$backup_file" "${zip_files[@]}" >/dev/null 2>&1; then

        # 恢复原始目录（成功分支）
        cd "$original_dir" 2>/dev/null || true

        # 获取备份文件大小
        local file_size=$(du -h "$backup_file" | cut -f1)
        log "✅ 备份完成！"
        log "备份文件: ${green}$backup_file${none}"
        log "文件大小: ${cyan}$file_size${none}"
        
        # 显示备份内容概览
        echo
        echo -e "${yellow}备份内容概览:${none}"
        echo "----------------------------------------------------------------"
        zip -sf "$backup_file"
        local total_files=$(zip -sf "$backup_file" | wc -l)
        echo "----------------------------------------------------------------"
        echo -e "总计: ${cyan}$total_files${none} 个文件"
        
    else
        # 恢复原始目录（成功分支）
        cd "$original_dir" 2>/dev/null || true
        error_exit "备份失败"
    fi
    
    echo
    echo "================================================================"
    log "${green}🎉 数据备份完成！${none}"
    echo -e "备份文件位置: ${cyan}$backup_file${none}"
    echo "================================================================"
}



# 检查是否以root权限运行
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 确认备份
echo -e "${green}天神之眼数据备份工具${none}"
echo "================================================================"
echo "将备份天神之眼系统的用户数据和设置数据"
echo "备份文件将保存到/root/目录"
echo "================================================================"
echo

read -p "$(echo -e "是否继续备份? (${green}y${none}/${red}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${yellow}备份已取消${none}"
    exit 0
fi

# 开始备份
backup_caddy_data