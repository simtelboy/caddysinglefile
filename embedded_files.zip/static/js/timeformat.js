
function parseTimeString(timeString) {
     // 解析时间字符串，提取日期时间部分和时区信息
    const [datePart, timePart, ...rest] = timeString.split(' ');
    const [year, month, day] = datePart.split('-').map(Number);
    const [hour, minute, second] = timePart.split(':').map(Number);

    // 创建Date对象，使用UTC时间
    const date = new Date(Date.UTC(year, month - 1, day, hour, minute, second));

    // 查找时区偏移
    const offsetMatch = rest.find(part => part.match(/[+-]\d{4}/));
    if (offsetMatch) {
        const offsetHours = parseInt(offsetMatch.substring(1, 3));
        const offsetMinutes = parseInt(offsetMatch.substring(3));
        const totalOffsetMinutes = (offsetMatch[0] === '+' ? -1 : 1) * (offsetHours * 60 + offsetMinutes);
        date.setUTCMinutes(date.getUTCMinutes() + totalOffsetMinutes);
    }

    return date;
}

function timeDifferenceDescription(timeString) {
    const inputDate = parseTimeString(timeString);
    const now = new Date();
    const difference = now - inputDate; // 注意：这里改为 now - inputDate

    const describeDifference = (diff) => {
        const msPerSecond = 1000;
        const msPerMinute = 60 * msPerSecond;
        const msPerHour = 60 * msPerMinute;
        const msPerDay = 24 * msPerHour;

        if (diff < msPerSecond) {
            return "刚刚";
        } else if (diff < msPerMinute) {
            return `${Math.floor(diff / msPerSecond)}秒前`;
        } else if (diff < msPerHour) {
            return `${Math.floor(diff / msPerMinute)}分钟前`;
        } else if (diff < msPerDay) {
            return `${Math.floor(diff / msPerHour)}小时前`;
        } else {
            return `${Math.floor(diff / msPerDay)}天前`;
        }
    };

    if (difference >= 0) {
        return describeDifference(difference);
    } else {
        // 如果是未来时间
        return describeDifference(-difference).replace('前', '后');
    }
}

//字节单位
function formatFileSize(bytes) {
    if (bytes === '-1') {
        return "不限额";
    }

    const units = ['Byte', 'KiB', 'MiB', 'GiB', 'TiB'];
    let unitIndex = 0;
    let size = Math.abs(bytes);
    let isNegative = false;

    if (bytes < 0) {
        isNegative = true;
    }

    while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
    }

    let formattedSize = unitIndex > 0 ? size.toFixed(2) : Math.floor(size);

    if (isNegative && bytes !== -1) {
        formattedSize = '超额' + formattedSize;
    }

    return formattedSize + ' ' + units[unitIndex];
}

//北京时间转换函数
function convertToBeijingTime(timeString) {
     // 解析时间字符串，获取 Date 对象
    const date = parseTimeString(timeString);

    // 直接格式化为中文时间格式（系统已设置为北京时间）
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };

    // 使用中文格式化
    const formattedTime = date.toLocaleString('zh-CN', options);

    // 将格式化后的日期字符串进行替换，得到最终结果
    return formattedTime.replace(/年/g, '年').replace(/月/g, '月').replace(/日/g, '日 ');
}

//根据ip地址返回归属地
async function fetchIPDetails(ip, includeIP = false, fields = []) {  
    const apiUrl = `https://api.songzixian.com/api/ip?dataSource=generic_ip&ip=${ip}`;  
  
    try {  
        const response = await fetch(apiUrl);  
        const result = await response.json();  
  
        if (result.code !== 200) {  
            throw new Error(`API 响应错误: ${result.message}`);  
        }  
  
        const { country, province, city, district, isp } = result.data;  
  
        // 如果 fields 数组为空，默认为 ['city', 'district', 'isp']  
        if (fields.length === 0) {  
            fields = ['city', 'district', 'isp'];  
        }  
  
        // 按要求的字段返回结果  
        const filteredResult = fields.map(field => result.data[field]).filter(value => value !== undefined);  
        let resultText = filteredResult.join(' ');  
  
        // 如果 includeIP 为 true，在结果后面添加 IP 地址  
        if (includeIP) {  
            resultText += ` [${ip}]`;  
        }  
  
        return resultText;  
    } catch (error) {  
        console.error('Error fetching IP details:', error);  
       // return '无法获取IP详情';  
       // return ip;          //无法获取就返回原IP  
        // 返回包含真实IP的HTML链接
        return `<a href="https://www.ipshudi.com/${ip}.htm">${ip}</a>`; 
    }  
  
    /*      返回示例  
    {  
  "requestId": "1817429260147757056",  
  "code": 200,  
  "message": "正常响应",  
  "data": {  
    "ip": "120.230.93.202",  
    "ipVersion": "ipv4",  
    "countryCode": "CN",  
    "country": "中国",  
    "accuracy": "区/县",  
    "region": "华南",  
    "province": "广东",  
    "city": "广州",  
    "district": "天河区",  
    "districtCode": "440106",  
    "longitude": 113.3612,  
    "latitude": 23.12468,  
    "isp": "中国移动"  
  }  
}  
  
    * */  
  
}

