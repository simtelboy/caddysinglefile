/*
function convertToCST(timeString) {
    // 时区映射表，键是时区缩写，值是与UTC的时差（小时）
    const timezoneOffsets = {
        "HAST": -10,
        "HST": -10,
        "ANAST": -11,
        "ANAT": -11,
        "XST": -11,
        "AZOT": -4,
        "LHDT": -11,
        "LHST": -10.5,
        "HAP": -10,
        "HKT": -8,
        "GAMT": -9,
        "GIT": -10,
        "AKST": -9,
        "GILT": -12,
        "HKT": -8,
        "PGT": -10,
        "PST": -8,
        "AKDT": -9,
        "CST": -6,
        "EST": -5,
        "ETC": -6,
        "GALT": -6,
        "MDT": -6,
        "EST": -5,
        "EDT": -4,
        "ET": -5,
        "ETC": -4,
        "PET": -5,
        "AST": -4,
        "ADT": -3,
        "FKT": -4,
        "GYT": -4,
        "PYT": -4,
        "PYT": -3,
        "ART": -3,
        "ARST": -3,
        "BRT": -3,
        "CET": -1,
        "CEST": +1,
        "CET": -2,
        "CEST": +2,
        "MSK": +3,
        "AZT": +4,
        "AZST": +4,
        "AZOT": -4,
        "AZT": +4,
        "IRDT": +4.5,
        "IRT": +4.5,
        "AZT": +5,
        "AZST": +5,
        "NPT": +5.75,
        "BNT": 8,
        "BTT": +6,
        "MMT": +6.5,
        "SLT": +6,
        "CCT": +6.5,
        "CXT": +7,
        "MMT": +6.5,
        "BNT": 8,
        "BTT": 8,
        "KRAT": +7,
        "KRAST": 8,
        "HKT": 8,
        "CST": 8,
        "KRST": +9,
        "LHST": +10.5,
        "AEDT": +11,
        "AEST": +10,
        "AWDT": 8,
        "AWST": 8,
        "JST": +9,
        "AEDT": +10.5,
        "LHST": +11,
        "AEDT": +11,
        "AEST": +10,
        "AEST": +10,
        "LHST": +11.5,
        "LHDT": +12,
        "ANZDT": +13,
        "ANZST": +12,
        "NZDT": +13,
        "NZST": +12,
        "LHDT": +14
    };
    // 解析时间字符串，提取日期时间部分和时区缩写
    const [dateTimePart, timezonePart] = timeString.split(/\s([+-]\d{4})/);
    const timezoneAbbr = timezonePart.trim().toUpperCase();

    // 获取时区偏移，如果没有找到时区缩写，则默认为0
    const offset = timezoneOffsets[timezoneAbbr] || 0;

    // 计算输入时间的UTC时间
    const utcTime = new Date(dateTimePart + "Z").getTime();

    // 如果时区偏移已经是8（UTC+8），则不需要转换
    if (offset === 8) {
        return new Date(utcTime).toISOString().replace('Z', '').replace(/\.\d{3}/, '');
    }

    // 计算北京时间（CST）时间
    const cstTime = utcTime + (8 - offset) * 60 * 60 * 1000;

    // 创建新的Date对象，代表北京时间
    const cstDateObject = new Date(cstTime);

    // 返回格式化的北京时间字符串
    return cstDateObject.toISOString().replace('Z', '').replace(/\.\d{3}/, '');
}

function timeDifferenceDescription(timeString) {
    // 使用convertToCST函数将输入的时间转换为Date对象
    const inputDate = new Date(convertToCST(timeString));

    // 获取当前时间的Date对象
    const now = new Date();
    const difference = inputDate - now;

    // 定义时间差描述的函数
    const describeDifference = (diff) => {
        const msPerSecond = 1000;
        const msPerMinute = 60 * msPerSecond;
        const msPerHour = 60 * msPerMinute;
        const msPerDay = 24 * msPerHour;

        if (diff < msPerSecond && diff >= 0) {
            return "刚刚";
        } else if (diff < msPerMinute) {
            return `${Math.floor(diff / msPerSecond)}秒前`;
        } else if (diff < msPerHour) {
            return `${Math.floor(diff / msPerMinute)}分钟前`;
        } else if (diff < msPerDay) {
            return `${Math.floor(diff / msPerHour)}小时前`;
        } else {
            return `${Math.floor(diff / msPerDay)}天前`;
        }
    };

    // 如果时间在未来
    if (difference > 0) {
        return describeDifference(difference);
    }

    // 如果时间在当前时间之前
    if (difference < 0) {
        return describeDifference(-difference); // 使用正值调用描述函数
    }

    // 如果时间恰好是当前时间
    return "现在";
}*/

function parseTimeString(timeString) {
    // 解析时间字符串,提取日期时间部分和时区信息
    const [datePart, timePart, ...rest] = timeString.split(' ');
    const [year, month, day] = datePart.split('-').map(Number);
    const [hour, minute, second] = timePart.split(':').map(Number);

    // 创建Date对象,使用UTC时间
    const date = new Date(Date.UTC(year, month - 1, day, hour, minute, second));

    // 查找时区偏移
    const offsetMatch = rest.find(part => part.match(/[+-]\d{4}/));
    if (offsetMatch) {
        const offsetHours = parseInt(offsetMatch.substring(1, 3));
        const offsetMinutes = parseInt(offsetMatch.substring(3));
        const totalOffsetMinutes = (offsetMatch[0] === '+' ? -1 : 1) * (offsetHours * 60 + offsetMinutes);
        date.setUTCMinutes(date.getUTCMinutes() + totalOffsetMinutes);
    }

    return date;
}

function timeDifferenceDescription(timeString) {
    const inputDate = parseTimeString(timeString);
    const now = new Date();
    const difference = inputDate - now;

    const describeDifference = (diff) => {
        const msPerSecond = 1000;
        const msPerMinute = 60 * msPerSecond;
        const msPerHour = 60 * msPerMinute;
        const msPerDay = 24 * msPerHour;

        if (diff < msPerSecond) {
            return "刚刚";
        } else if (diff < msPerMinute) {
            return `${Math.floor(diff / msPerSecond)}秒前`;
        } else if (diff < msPerHour) {
            return `${Math.floor(diff / msPerMinute)}分钟前`;
        } else if (diff < msPerDay) {
            return `${Math.floor(diff / msPerHour)}小时前`;
        } else {
            return `${Math.floor(diff / msPerDay)}天前`;
        }
    };

    const describeFutureDifference = (diff) => {
        const msPerSecond = 1000;
        const msPerMinute = 60 * msPerSecond;
        const msPerHour = 60 * msPerMinute;
        const msPerDay = 24 * msPerHour;

        if (diff < msPerSecond) {
            return "刚刚";
        } else if (diff < msPerMinute) {
            return `${Math.floor(diff / msPerSecond)}秒后`;
        } else if (diff < msPerHour) {
            return `${Math.floor(diff / msPerMinute)}分钟后`;
        } else if (diff < msPerDay) {
            return `${Math.floor(diff / msPerHour)}小时后`;
        } else {
            return `${Math.floor(diff / msPerDay)}天后`;
        }
    };

    if (difference > 0) {
        return describeFutureDifference(difference);
    }

    return describeDifference(-difference);
}

//字节单位
function formatFileSize(bytes) {
    if (bytes === '-1') {
        return "不限额";
    }

    const units = ['Byte', 'KiB', 'MiB', 'GiB', 'TiB'];
    let unitIndex = 0;
    let size = Math.abs(bytes);
    let isNegative = false;

    if (bytes < 0) {
        isNegative = true;
    }

    while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
    }

    let formattedSize = unitIndex > 0 ? size.toFixed(2) : Math.floor(size);

    if (isNegative && bytes !== -1) {
        formattedSize = '超额' + formattedSize;
    }

    return formattedSize + ' ' + units[unitIndex];
}

function convertToBeijingTime(timeString) {
    // 解析时间字符串,获取 Date 对象
    const date = parseTimeString(timeString);

    // 设置正确的选项
    const options = {
        timeZone: 'Asia/Shanghai',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };

    // 使用选项格式化日期字符串
    const formattedTime = date.toLocaleString('zh-CN', options);

    // 将格式化后的日期字符串进行替换,得到最终结果
    return formattedTime.replace(/年/g, '年').replace(/月/g, '月').replace(/日/g, '日 ');
}

//根据ip地址返回归属地
async function fetchIPDetails(ip, includeIP = false, fields = []) {  
    const apiUrl = `https://api.songzixian.com/api/ip?dataSource=generic_ip&ip=${ip}`;  
  
    try {  
        const response = await fetch(apiUrl);  
        const result = await response.json();  
  
        if (result.code !== 200) {  
            throw new Error(`API 响应错误: ${result.message}`);  
        }  
  
        const { country, province, city, district, isp } = result.data;  
  
        // 如果 fields 数组为空，默认为 ['city', 'district', 'isp']  
        if (fields.length === 0) {  
            fields = ['city', 'district', 'isp'];  
        }  
  
        // 按要求的字段返回结果  
        const filteredResult = fields.map(field => result.data[field]).filter(value => value !== undefined);  
        let resultText = filteredResult.join(' ');  
  
        // 如果 includeIP 为 true，在结果后面添加 IP 地址  
        if (includeIP) {  
            resultText += ` [${ip}]`;  
        }  
  
        return resultText;  
    } catch (error) {  
        console.error('Error fetching IP details:', error);  
       // return '无法获取IP详情';  
       // return ip;          //无法获取就返回原IP  
        // 返回包含真实IP的HTML链接
        return `<a href="https://www.ipshudi.com/${ip}.htm">${ip}</a>`; 
    }  
  
    /*      返回示例  
    {  
  "requestId": "1817429260147757056",  
  "code": 200,  
  "message": "正常响应",  
  "data": {  
    "ip": "120.230.93.202",  
    "ipVersion": "ipv4",  
    "countryCode": "CN",  
    "country": "中国",  
    "accuracy": "区/县",  
    "region": "华南",  
    "province": "广东",  
    "city": "广州",  
    "district": "天河区",  
    "districtCode": "440106",  
    "longitude": 113.3612,  
    "latitude": 23.12468,  
    "isp": "中国移动"  
  }  
}  
  
    * */  
  
}

