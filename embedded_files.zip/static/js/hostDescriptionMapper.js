function getHostDescription(host, agent) {
    const hostMapping = {
        '谷歌': ['*google*', '*g.cn*','*gstatic.com*'],
        'jsDelivr CDN': ['*jsdelivr*'],
        '亚马逊云': ['*amazonaws*'],
        'UCloud': ['*ucloud*'],
        '色情网站': ['*91porny*', '*mwbbiz*'],
        '91色情网站': ['*91porn*'],
        'whatsapp': ['*whatsapp*'],
        '好色网': ['*hsex*'],
        '证书服务': ['*lencr.org*'],
        'TikTok': ['*i18n*','pglstatp','*pangle.io*'],
        'POE': ['*poe.com*'],
        '浏览器深色插件': ['*darkreader.org*'],
        'loom录屏': ['*loom.com*'],
        '微软': ['*microsoft*'],
        '苹果': ['*apple*'],
        '推特': ['*twitter*','*x.com*'],
        '维基百科': ['wikimedia'],
        '电报': ['*telegram*'],
        'YouTube':['*ytimg.com*','*youtube*','*googlevideo.com*','*ggpht*']
    };

    //全文匹配
    const exactHostMapping = {
         'UCloud 内部服务': ['int.ucloud111.xyz'],
        'jsDelivr 静态资源': ['gw.jstatic.xyz'],
        'jsDelivr Fastly CDN': ['fastly.jsdelivr.net'],
        'Cloudflare 洞察': ['static.cloudflareinsights.com'],
        '色情网站': ['int.mwbbiz.com']
    };

    const userAgentMapping = {
        '客户端APP': ['*nghttp2*', '*HTTP/2*'],
        '浏览器请求': ['*Chrome*', '*Safari*', '*Firefox*'],
        '移动设备请求': ['*Android*', '*iOS*']
    };

    //排除列表.模糊查找
    const excludeList = [
        'rapidssl.com',
        'geotrust.com',
        'poecdn.net',
        'digicert.com',
        'dap.pat-issuer.cloudflare.com',
        'rr2---sn-a5msenl7.googlevideo.com',
        'githubusercontent.com',
        'calendar',
        'twimg.com',
    ];

    let hostResult;
    let agentResult;

    // 第一步: 模糊查找目标列
    for (const description in hostMapping) {
        for (const keyword of hostMapping[description]) {
            if (host.includes(keyword.replace(/\*/g, ''))) {
                hostResult = description;
                break;
            }
        }
        if (hostResult) break;
    }

    // 第二步: 精确匹配目标列
    for (const description in exactHostMapping) {
        if (exactHostMapping[description].includes(host)) {
            hostResult = description;
            break;
        }
    }

    // 第三步: 模糊查找备注列
    for (const description in userAgentMapping) {
        for (const keyword of userAgentMapping[description]) {
            if (agent.includes(keyword.replace(/\*/g, ''))) {
                agentResult = description;
                break;
            }
        }
        if (agentResult) break;
    }

    // 第四步: 提取域名
    if (!hostResult) {
        const domain = host.split('.').slice(-2).join('.');
        if (domain.includes('.')) {
            hostResult = domain;
        } else {
            hostResult = host;
        }
    }

    // 检查域名是否在排除列表中
    for (const excludeKeyword of excludeList) {
        if (hostResult.includes(excludeKeyword.replace(/\*/g, ''))) {
            return null;
        }
    }

    return {
        host: hostResult,
        agent: agentResult || agent
    };
}


document.addEventListener('DOMContentLoaded',async function (){
    const spanHosts = document.querySelectorAll('.spanhost');
    const spanAgents = document.querySelectorAll('.spanagent');

    const uniqueHosts = {};

    for (let i = 0; i < spanHosts.length; i++) {
        const host = spanHosts[i].textContent;
        const agent = spanAgents[i].textContent;
        const description = getHostDescription(host, agent);

        if(!description){
            //如果description 为 null,表示该条目应该被排除,从DOM中移除对应的<tr>元素
            const currentRow = spanHosts[i].closest('tr');
            currentRow.remove()
            continue;
        }

        if (uniqueHosts[description.host]) {
            // 如果 description.host 已经出现过,将旧行的 class 设置为 'hidden-row'
            uniqueHosts[description.host].forEach(row => row.classList.add('hidden-row'));
        }

        // 更新元素的文本内容并记录下来,以便后续比较
        spanHosts[i].textContent = description.host;
        spanAgents[i].textContent = description.agent;

        const currentRow = spanHosts[i].closest('tr');
        if (!uniqueHosts[description.host]) {
            uniqueHosts[description.host] = [];
        }
        uniqueHosts[description.host].push(currentRow);

        // 为当前行添加点击事件监听器
        currentRow.addEventListener('click', function() {
            // 切换旧行的可见性
            uniqueHosts[description.host].forEach(row => {
                if (row !== currentRow) {
                    row.classList.toggle('hidden-row');
                }
            });
        });
    }
});