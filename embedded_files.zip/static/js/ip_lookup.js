const ipRanges = {
    //标头不能以数字开头
    Telegram: {
        ranges: [
            '91.108.4.0/22',
            '91.108.8.0/22',
            '91.108.56.0/22',
            '95.161.64.0/20',
            '149.154.160.0/22',
            '149.154.160.0/23',
            '149.154.162.0/23',
            '149.154.164.0/22',
            '149.154.164.0/23',
            '149.154.166.0/23',
            '91.108.20.0/22',
            '91.108.20.0/23',
            '91.108.12.0/22',
            '149.154.172.0/22'
        ],
        description: 'Telegram'
    },
    pron91:{
        ranges:[
            '172.67.199.177/32',
            '104.21.50.21/32'
        ],
        description:'91网'
    },
    hsex:{
        ranges:[
            '172.67.216.62/32',
            '104.21.16.218/32'
        ],
        description:'好色网'
    },
    Youtube: {
        ranges: [
            '199.223.232.0/21',
            '207.223.160.0/20',
            '208.65.152.0/22',
            '208.117.224.0/19',
            '209.85.128.0/17',
            '216.58.192.0/19',
            '216.239.32.0/19'
        ],
        description: '油管'
    },
    WhatsApp: {
        ranges: [
            '3.33.221.48/32',
            '3.33.252.61/32',
            '15.197.206.217/32',
            '15.197.210.208/32',
            '31.13.64.0/21',
            '34.192.181.12/32',
            '34.193.38.112/32',
            '34.194.71.217/32',
            '34.194.255.230/32',
            '69.171.250.60/31',
            '102.132.96.0/20',
            '157.240.0.0/20',
            '157.240.192.0/20',
            '163.70.128.0/26',
            '179.60.192.0/22',
            '185.60.216.0/23'
        ],
        description: 'WhatsApp'
    },
    google: {
        ranges: [
            '64.233.160.0/19',
            '66.102.0.0/20',
            '66.249.80.0/20',
            '72.14.192.0/18',
            '74.125.0.0/16',
            '108.177.8.0/21',
            '173.194.0.0/16',
            '209.85.128.0/17',
            '216.58.192.0/19',
            '216.239.32.0/19',
            '172.217.0.0/19',
            '172.217.32.0/20',
            '172.217.128.0/19',
            '172.217.160.0/20',
            '172.217.192.0/19',
            '108.177.96.0/19'
        ],
        description: '谷歌'
    },
};

function ipToLong(ip) {
    const octets = ip.split('.');
    return (octets[0] << 24) + (octets[1] << 16) + (octets[2] << 8) + parseInt(octets[3], 10);
}

function isIPInRange(ip, range) {
    const [rangeIP, cidr] = range.split('/');
    const rangeLong = ipToLong(rangeIP);
    const ipLong = ipToLong(ip);
    const mask = -1 << (32 - parseInt(cidr, 10));
    return (ipLong & mask) === (rangeLong & mask);
}

function getServiceProviderByIP(ip) {
    for (const [provider, data] of Object.entries(ipRanges)) {
        for (const range of data.ranges) {
            if (isIPInRange(ip, range)) {
                return data.description;
            }
        }
    }
    return ip;
}

