#!/bin/bash

# 天神之眼更新脚本（强制更新 - rm 后 cp 版）
# 先删除旧文件再复制，解决 Text file busy 问题

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 错误处理
error_exit() {
    log "${red}❌ $1${none}"
    exit 1
}

# 获取最新版本的文件名
get_latest_caddy_filename() {
    local arch=$(uname -m)
    case $arch in
        x86_64) echo "caddy-v2.10.2-linux-amd64" ;;
        aarch64|arm64) echo "caddy-v2.10.2-linux-arm64" ;;
        armv7l) echo "caddy-v2.10.2-linux-armv7" ;;
        *) error_exit "不支持的架构: $arch" ;;
    esac
}

# 下载函数（带重试）
download_with_retry() {
    local url=$1
    local output=$2
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        log "尝试下载 (第 $attempt 次)..."
        if curl -L --connect-timeout 10 --max-time 300 -o "$output" "$url"; then
            if [ -f "$output" ] && [ -s "$output" ]; then
                log "✅ 下载成功"
                return 0
            fi
        fi
        
        log "⚠️ 下载失败，等待重试..."
        sleep 5
        ((attempt++))
    done
    
    return 1
}

# 检查资源
check_resources() {
    local tmp_space=$(df /var/tmp | tail -1 | awk '{print $4}')
    local mem_free=$(free -m | awk '/^Mem:/ {print $7}')
    
    if [[ $tmp_space -lt 100000 ]]; then  # <100MB
        error_exit "临时目录空间不足 (<100MB)"
    fi
    if [[ $mem_free -lt 100 ]]; then  # <100MB
        error_exit "可用内存不足 (<100MB)"
    fi
    log "✅ 资源检查通过 (空间: ${tmp_space}KB, 内存: ${mem_free}MB)"
}

# 检查文件权限
check_permissions() {
    if [[ -f /usr/bin/caddy ]]; then
        lsattr /usr/bin/caddy 2>/dev/null | grep -q 'i' && {
            log "移除 immutable 属性..."
            chattr -i /usr/bin/caddy || error_exit "无法移除 immutable 属性"
        }
        log "✅ 文件权限检查通过"
    fi
}

# 主更新函数
update_caddy() {
    echo -e "${yellow}🚀 开始强制更新天神之眼...${none}"
    echo "================================================================"
    
    # 检查当前版本（仅记录）
    if command -v caddy >/dev/null 2>&1; then
        current_version=$(caddy version 2>/dev/null | head -n1 || echo "未知版本")
        log "当前版本: ${cyan}$current_version${none}"
    else
        log "${yellow}未检测到已安装的天神之眼${none}"
    fi
    
    # 资源检查
    check_resources
    
    # 获取最新版本信息
    log "获取最新版本信息..."
    local filename=$(get_latest_caddy_filename)
    local download_url="https://github.com/simtelboy/eye/releases/latest/download/$filename"
    
    log "下载天神之眼: $filename"
    local temp_dir="/var/tmp/caddy_update_$$"
    mkdir -p "$temp_dir"
    cd "$temp_dir"
    
    if download_with_retry "$download_url" "$filename"; then
        log "准备更新天神之眼..."
        
        # 检查权限
        check_permissions
        
        # 停止服务并等待
        log "停止天神之眼服务..."
        systemctl stop caddy 2>/dev/null || error_exit "无法停止 Caddy 服务"
        log "等待 15 秒确保服务完全停止..."
        sleep 15
        
        local backup_name=""
        
        # 备份当前版本
        if [[ -f "/usr/bin/caddy" ]]; then
            backup_name="/usr/bin/caddy.backup.$(date +%s)"
            if cp /usr/bin/caddy "$backup_name" 2>/dev/null; then
                log "当前版本已备份到: ${cyan}$backup_name${none}"
            else
                log "${yellow}⚠️ 备份失败，但继续更新${none}"
            fi
        fi
        
        # 删除旧文件并安装新版本
        log "删除旧版本..."
        rm -f /usr/bin/caddy 2>>/tmp/caddy-update-error.log
        if [[ -f /usr/bin/caddy ]]; then
            error_exit "删除旧版本失败，详情见 /tmp/caddy-update-error.log"
        fi
        log "安装新版本..."
        if cp "$filename" /usr/bin/caddy 2>>/tmp/caddy-update-error.log; then
            chmod +x /usr/bin/caddy
            if [[ -f /usr/bin/caddy && -x /usr/bin/caddy ]]; then
                log "✅ 新版本安装并验证成功"
            else
                error_exit "文件覆盖失败，验证未通过"
            fi
        else
            local cp_error=$(cat /tmp/caddy-update-error.log 2>/dev/null | tail -1)
            error_exit "安装失败: $cp_error"
        fi
        
        # 重启服务
        log "重启天神之眼服务..."
        systemctl start caddy
        sleep 3
        
        # 检查服务状态
        if systemctl is-active --quiet caddy; then
            new_version=$(caddy version 2>/dev/null | head -n1 || echo "未知版本")
            log "✅ 天神之眼更新成功！"
            log "新版本: ${green}$new_version${none}"
        else
            log "${red}❌ 服务启动失败，正在回滚...${none}"
            # 回滚
            if [[ -f "$backup_name" ]]; then
                cp "$backup_name" /usr/bin/caddy 2>/dev/null || true
                chmod +x /usr/bin/caddy
                systemctl start caddy
                log "已回滚到之前版本"
            fi
            cd /
            rm -rf "$temp_dir"
            rm -f /tmp/caddy-update-error.log
            exit 1
        fi
        
        # 清理
        cd /
        rm -rf "$temp_dir"
        rm -f /tmp/caddy-update-error.log
        
        echo "================================================================"
        log "${green}🎉 更新完成！${none}"
        
    else
        log "${red}❌ 下载失败，更新中止${none}"
        cd /
        rm -rf "$temp_dir"
        exit 1
    fi
}

# 检查 root 权限
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 确认更新
echo -e "${green}天神之眼更新工具${none}"
echo "================================================================"
echo "此脚本将强制更新天神之眼到最新版本"
echo "================================================================"
echo

read -p "$(echo -e "是否继续更新? (${green}y${none}/${red}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${yellow}更新已取消${none}"
    exit 0
fi

# 开始更新
update_caddy