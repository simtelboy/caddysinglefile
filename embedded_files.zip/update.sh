#!/bin/bash

# 天神之眼更新脚本
# 基于原始更新脚本修改

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 错误处理
error_exit() {
    log "${red}❌ $1${none}"
    exit 1
}

# 获取最新版本的文件名
get_latest_caddy_filename() {
    local arch=$(uname -m)
    case $arch in
        x86_64) echo "caddy-v2.10.2-linux-amd64" ;;
        aarch64|arm64) echo "caddy-v2.10.2-linux-arm64" ;;
        armv7l) echo "caddy-v2.10.2-linux-armv7" ;;
        *) error_exit "不支持的架构: $arch" ;;
    esac
}

# 下载函数（带重试）
download_with_retry() {
    local url=$1
    local output=$2
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        log "尝试下载 (第 $attempt 次)..."
        if curl -L --connect-timeout 10 --max-time 300 -o "$output" "$url"; then
            if [ -f "$output" ] && [ -s "$output" ]; then
                log "✅ 下载成功"
                return 0
            fi
        fi
        
        log "⚠️ 下载失败，等待重试..."
        sleep 5
        ((attempt++))
    done
    
    return 1
}

# 主更新函数
update_caddy() {
    echo -e "${yellow}🚀 开始更新天神之眼...${none}"
    echo "================================================================"
    
    # 检查当前版本
    if command -v caddy >/dev/null 2>&1; then
        current_version=$(caddy version 2>/dev/null | head -n1 || echo "未知版本")
        log "当前版本: ${cyan}$current_version${none}"
    else
        log "${yellow}未检测到已安装的天神之眼${none}"
    fi
    
    # 创建临时目录
    local temp_dir="/tmp/caddy_update_$$"
    mkdir -p "$temp_dir"
    cd "$temp_dir"
    
    # 获取最新版本信息
    log "获取最新版本信息..."
    local filename=$(get_latest_caddy_filename)
    local download_url="https://github.com/simtelboy/eye/releases/latest/download/$filename"
    
    log "下载天神之眼: $filename"
    if download_with_retry "$download_url" "$filename"; then
        log "准备更新天神之眼..."
        
        # 停止服务
        log "停止天神之眼服务..."
        systemctl stop caddy 2>/dev/null || true
        
        # 备份当前版本
        if [[ -f "/usr/bin/caddy" ]]; then
            backup_name="/usr/bin/caddy.backup.$(date +%s)"
            cp /usr/bin/caddy "$backup_name" 2>/dev/null || true
            log "当前版本已备份到: ${cyan}$backup_name${none}"
        fi
        
        # 安装新版本
        log "安装新版本..."
        cp "$filename" /usr/bin/caddy
        chmod +x /usr/bin/caddy
        
        # 重启服务
        log "重启天神之眼服务..."
        systemctl start caddy
        
        # 等待服务启动
        sleep 3
        
        # 检查服务状态
        if systemctl is-active --quiet caddy; then
            new_version=$(caddy version 2>/dev/null | head -n1 || echo "未知版本")
            log "✅ 天神之眼更新成功！"
            log "新版本: ${green}$new_version${none}"
        else
            log "${red}❌ 服务启动失败，正在回滚...${none}"
            # 回滚到备份版本
            if [[ -f "$backup_name" ]]; then
                cp "$backup_name" /usr/bin/caddy
                systemctl start caddy
                log "已回滚到之前版本"
            fi
            cd /
            rm -rf "$temp_dir"
            exit 1
        fi
        
        # 清理临时文件
        cd /
        rm -rf "$temp_dir"
        
        echo "================================================================"
        log "${green}🎉 更新完成！${none}"
        
    else
        log "${red}❌ 下载失败，更新中止${none}"
        cd /
        rm -rf "$temp_dir"
        exit 1
    fi
}

# 检查是否以root权限运行
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 确认更新
echo -e "${green}天神之眼更新工具${none}"
echo "================================================================"
echo "此脚本将更新天神之眼到最新版本"
echo "================================================================"
echo

read -p "$(echo -e "是否继续更新? (${green}y${none}/${red}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${yellow}更新已取消${none}"
    exit 0
fi

# 开始更新
update_caddy