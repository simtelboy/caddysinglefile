#!/bin/bash

# 天神之眼自动更新管理脚本
# 用于开启、关闭自动更新功能以及查看状态，优化与新更新逻辑一致

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a /var/log/caddy-auto-update.log
}

# 错误处理
error_exit() {
    log "❌ 错误: $1"
    exit 1
}

# 成功信息
success() {
    echo -e "${green}✅ $1${none}"
}

# 警告信息
warning() {
    echo -e "${yellow}⚠️ $1${none}"
}

# 信息提示
info() {
    echo -e "${cyan}ℹ️ $1${none}"
}

# 获取本地版本
get_local_version() {
    if command -v caddy >/dev/null 2>&1; then
        caddy version 2>/dev/null | awk '{print $1}' || echo "unknown"
    else
        echo "not_installed"
    fi
}

# 获取最新版本
get_latest_version() {
    curl -s https://api.github.com/repos/simtelboy/eye/releases/latest | jq -r '.tag_name' 2>/dev/null || echo "unknown"
}

# 计算服务器时间对应的本地时间
calculate_server_time_for_local() {
    local local_hour="$1"
    local local_min="${2:-0}"
    
    # 动态获取系统时区偏移
    local server_offset_str=$(date +%z)
    local server_offset_hours=$((${server_offset_str:1:2}))
    if [[ "${server_offset_str:0:1}" == "-" ]]; then
        server_offset_hours=$((0 - server_offset_hours))
    fi
    
    # 假设用户指定本地时区（默认 UTC+8，可通过参数调整）
    local user_offset_hours=${3:-8}  # 默认 UTC+8，可通过第三个参数修改
    
    # 计算时差
    local time_diff=$((server_offset_hours - user_offset_hours))
    
    # 计算服务器时间
    local server_hour=$((local_hour + time_diff))
    local server_day="Sun"
    
    # 处理跨日期
    if [[ $server_hour -lt 0 ]]; then
        server_hour=$((server_hour + 24))
        server_day="Sat"
    elif [[ $server_hour -ge 24 ]]; then
        server_hour=$((server_hour - 24))
        server_day="Mon"
    fi
    
    printf "%s *-*-* %02d:%02d:00" "$server_day" "$server_hour" "$local_min"
}

# 检查自动更新状态
check_auto_update_status() {
    if systemctl is-active --quiet caddy-auto-update.timer 2>/dev/null; then
        return 0  # 已启用
    else
        return 1  # 未启用
    fi
}

# 显示版本信息
show_version_info() {
    echo -e "${blue}========== 版本信息 ==========${none}"
    
    local local_version=$(get_local_version)
    local latest_version=$(get_latest_version)
    
    echo -e "本地版本: ${cyan}$local_version${none}"
    echo -e "最新版本: ${cyan}$latest_version${none}"
    
    if [[ "$local_version" != "not_installed" && "$local_version" != "unknown" && "$latest_version" != "unknown" ]]; then
        if [[ $(echo -e "$local_version\n$latest_version" | sort -V | head -n1) == "$local_version" ]] && [[ "$local_version" != "$latest_version" ]]; then
            echo -e "状态: ${yellow}有新版本可用${none}"
        else
            echo -e "状态: ${green}已是最新版本${none}"
        fi
    else
        echo -e "状态: ${red}无法确定版本状态${none}"
    fi
    
    echo -e "${blue}=============================${none}"
}

# 显示当前状态
show_current_status() {
    echo -e "${yellow}========== 天神之眼自动更新状态 ==========${none}"
    
    if check_auto_update_status; then
        success "自动更新功能已启用"
        echo
        info "定时器状态:"
        systemctl status caddy-auto-update.timer --no-pager -l 2>>/var/log/caddy-update-error.log || warning "无法获取详细状态"
        
        echo
        info "下次执行时间:"
        systemctl list-timers caddy-auto-update.timer --no-pager 2>>/var/log/caddy-update-error.log || warning "无法获取执行时间"
        
        if [[ -f "/var/log/caddy-auto-update.log" ]]; then
            echo
            info "最近更新日志 (最后5行):"
            tail -5 /var/log/caddy-auto-update.log 2>>/var/log/caddy-update-error.log || warning "无法读取日志文件"
        fi
    else
        warning "自动更新功能未启用"
    fi
    echo -e "${yellow}===========================================${none}"
}

# 启用自动更新
enable_auto_update() {
    log "开始启用天神之眼自动更新功能..."
    
    # 检查是否已经启用
    if check_auto_update_status; then
        warning "自动更新功能已经启用，无需重复设置"
        return 0
    fi
    
    # 检查必要工具
    for tool in curl jq wget systemctl; do
        if ! command -v $tool >/dev/null 2>&1; then
            log "安装缺少的工具: $tool"
            apt update && apt install -y $tool 2>>/var/log/caddy-update-error.log || error_exit "无法安装 $tool"
        fi
    done
    
    # 检查自动更新脚本是否存在
    local updater_script="/etc/caddy/autoupdate_worker.sh"
    if [[ ! -f "$updater_script" ]]; then
        error_exit "找不到自动更新脚本: $updater_script"
    fi
    
    # 复制脚本到系统目录
    log "复制自动更新脚本到系统目录..."
    cp "$updater_script" /usr/local/bin/caddy-auto-updater.sh 2>>/var/log/caddy-update-error.log || error_exit "复制脚本失败"
    chmod +x /usr/local/bin/caddy-auto-updater.sh 2>>/var/log/caddy-update-error.log || error_exit "设置权限失败"
    
    # 创建 systemd 服务
    log "创建 systemd 服务..."
    cat > /etc/systemd/system/caddy-auto-update.service << 'EOF'
[Unit]
Description=天神之眼自动更新服务
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/caddy-auto-updater.sh
User=root
WorkingDirectory=/root

[Install]
WantedBy=multi-user.target
EOF

    # 计算正确的服务器时间（本地时间周一4点对应的服务器时间）
    local server_time=$(calculate_server_time_for_local 4 0)  # 本地时间4:00，UTC+8 假设
    
    log "计算的服务器执行时间: $server_time"
    
    # 创建 systemd 定时器
    log "创建 systemd 定时器..."
    cat > /etc/systemd/system/caddy-auto-update.timer << EOF
[Unit]
Description=天神之眼每周自动更新定时器
Requires=caddy-auto-update.service

[Timer]
OnCalendar=$server_time
Persistent=true

[Install]
WantedBy=timers.target
EOF

    # 启用定时器
    log "启用定时器..."
    systemctl daemon-reload 2>>/var/log/caddy-update-error.log || error_exit "重新加载 systemd 失败"
    systemctl enable caddy-auto-update.timer 2>>/var/log/caddy-update-error.log || error_exit "启用定时器失败"
    systemctl start caddy-auto-update.timer 2>>/var/log/caddy-update-error.log || error_exit "启动定时器失败"
    
    success "自动更新功能已启用"
    echo
    echo -e "${green}========== 设置完成 ==========${none}"
    echo -e "${yellow}定时器将在每周一凌晨4点（本地时间）检查更新${none}"
    echo -e "${yellow}对应服务器时间: $server_time${none}"
    echo
    info "管理命令:"
    echo "  查看定时器状态: systemctl status caddy-auto-update.timer"
    echo "  查看更新日志:   tail -f /var/log/caddy-auto-update.log"
    echo "  手动执行更新:   /usr/local/bin/caddy-auto-updater.sh"
    echo
}

# 禁用自动更新
disable_auto_update() {
    log "开始禁用天神之眼自动更新功能..."
    
    # 检查是否已经禁用
    if ! check_auto_update_status; then
        warning "自动更新功能已经禁用，无需重复操作"
        return 0
    fi
    
    # 停止并禁用定时器
    log "停止并禁用定时器..."
    systemctl stop caddy-auto-update.timer 2>>/var/log/caddy-update-error.log || true
    systemctl disable caddy-auto-update.timer 2>>/var/log/caddy-update-error.log || true
    
    # 删除文件
    log "删除相关文件..."
    rm -f /etc/systemd/system/caddy-auto-update.service 2>>/var/log/caddy-update-error.log
    rm -f /etc/systemd/system/caddy-auto-update.timer 2>>/var/log/caddy-update-error.log
    rm -f /usr/local/bin/caddy-auto-updater.sh 2>>/var/log/caddy-update-error.log
    
    # 重新加载 systemd
    systemctl daemon-reload 2>>/var/log/caddy-update-error.log
    
    success "自动更新功能已禁用"
}

# 手动执行更新
manual_update() {
    log "手动执行天神之眼更新检查..."
    
    local updater_script="/usr/local/bin/caddy-auto-updater.sh"
    if [[ ! -f "$updater_script" ]]; then
        # 尝试使用本地脚本
        updater_script="/etc/caddy/autoupdate_worker.sh"
        if [[ ! -f "$updater_script" ]]; then
            error_exit "找不到自动更新脚本"
        fi
    fi
    
    echo -e "${yellow}正在执行更新检查...${none}"
    if bash "$updater_script" 2>>/var/log/caddy-update-error.log; then
        local new_version=$(get_local_version)
        log "✅ 手动更新完成，当前版本: $new_version"
    else
        error_exit "手动更新失败，详情见 /var/log/caddy-update-error.log"
    fi
}

# 查看更新日志
view_update_log() {
    local log_file="/var/log/caddy-auto-update.log"
    
    if [[ ! -f "$log_file" ]]; then
        warning "更新日志文件不存在: $log_file"
        return 1
    fi
    
    echo -e "${yellow}========== 天神之眼更新日志 ==========${none}"
    echo -e "${cyan}日志文件: $log_file${none}"
    echo -e "${cyan}最后20行日志:${none}"
    echo
    tail -20 "$log_file" 2>>/var/log/caddy-update-error.log || warning "无法读取日志文件"
    echo
    echo -e "${yellow}=======================================${none}"
    echo
    info "查看完整日志: tail -f $log_file"
}

# 显示菜单
show_menu() {
    echo
    echo -e "${blue}========== 天神之眼自动更新管理 ==========${none}"
    echo -e "${green}1. 查看当前状态${none}"
    echo -e "${green}2. 启用自动更新${none}"
    echo -e "${green}3. 禁用自动更新${none}"
    echo -e "${green}4. 手动执行一次更新${none}"
    echo -e "${green}5. 查看更新日志${none}"
    echo -e "${green}6. 查看版本信息${none}"
    echo -e "${green}7. 退出${none}"
    echo -e "${blue}===========================================${none}"
    echo
}

# 主函数
main() {
    # 检查是否为 root 用户
    if [[ $EUID -ne 0 ]]; then
        error_exit "此脚本需要 root 权限运行，请使用 sudo"
    fi
    
    # 确保日志目录存在并有写权限
    mkdir -p /var/log
    touch /var/log/caddy-auto-update.log /var/log/caddy-update-error.log
    chmod 644 /var/log/caddy-auto-update.log /var/log/caddy-update-error.log
    
    # 如果有参数，直接执行对应操作
    case "${1:-}" in
        "enable"|"on")
            enable_auto_update
            exit 0
            ;;
        "disable"|"off")
            disable_auto_update
            exit 0
            ;;
        "status")
            show_current_status
            exit 0
            ;;
        "update")
            manual_update
            exit 0
            ;;
        "log")
            view_update_log
            exit 0
            ;;
        "version")
            show_version_info
            exit 0
            ;;
    esac
    
    # 交互式菜单
    while true; do
        show_current_status
        show_menu
        
        read -p "请选择操作 [1-7]: " choice
        
        case $choice in
            1)
                show_current_status
                ;;
            2)
                enable_auto_update
                ;;
            3)
                disable_auto_update
                ;;
            4)
                manual_update
                ;;
            5)
                view_update_log
                ;;
            6)
                show_version_info
                ;;
            7)
                echo -e "${yellow}退出脚本...${none}"
                exit 0
                ;;
            *)
                echo -e "${red}无效选择，请输入 1-7${none}"
                ;;
        esac
        
        echo
        read -p "按 Enter 键继续..." -r
    done
}

# 执行主函数
main "$@"