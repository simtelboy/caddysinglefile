#!/bin/bash

# 天神之眼卸载脚本

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 错误处理
error_exit() {
    log "${red}❌ $1${none}"
    exit 1
}

# 暂停函数
pause() {
    read -rsp "$(echo -e "按${cyan}Enter${none}键继续...或按${cyan}Ctrl+C${none}取消")" -d $'\n'
    echo
}

# 备份数据函数
backup_before_uninstall() {
    if [[ ! -d "/etc/caddy" ]]; then
        log "${yellow}未找到配置目录，跳过备份${none}"
        return 0
    fi
    
    log "卸载前自动备份数据..."
    
    # 生成备份文件名
    local backup_time=$(date '+%Y%m%d_%H%M%S')
    local backup_file="/root/caddy_data_All_backup_${backup_time}.zip"
    
    # 检查zip命令
    if ! command -v zip >/dev/null 2>&1; then
        log "安装zip工具..."
        apt update -qq && apt install -y zip || {
            log "${yellow}⚠️  无法安装zip，跳过备份${none}"
            return 0
        }
    fi
    
    # 创建备份
    cd /etc
    if zip -r "$backup_file" caddy/ >/dev/null 2>&1; then
        local file_size=$(du -h "$backup_file" | cut -f1)
        log "✅ 备份完成: ${cyan}$backup_file${none} (${file_size})"
    else
        log "${yellow}⚠️  备份失败，继续卸载${none}"
    fi
}

# 主卸载函数
uninstall_caddy() {
    echo -e "${yellow}🗑️  开始卸载天神之眼...${none}"
    echo "================================================================"
    
    # 卸载前备份
    backup_before_uninstall
    
    # 停止并禁用服务
    log "停止天神之眼服务..."
    systemctl stop caddy 2>/dev/null || true
    systemctl disable caddy 2>/dev/null || true
    
    # 删除systemd服务文件
    if [[ -f "/etc/systemd/system/caddy.service" ]]; then
        log "删除系统服务文件..."
        rm -f /etc/systemd/system/caddy.service
        systemctl daemon-reload
    fi
    
    # 删除可执行文件
    if [[ -f "/usr/bin/caddy" ]]; then
        log "删除可执行文件..."
        rm -f /usr/bin/caddy
    fi
    
    # 删除配置目录
    if [[ -d "/etc/caddy" ]]; then
        log "删除配置目录..."
        rm -rf /etc/caddy
    fi
    
    # 删除数据目录
    if [[ -d "/var/lib/caddy" ]]; then
        log "删除数据目录..."
        rm -rf /var/lib/caddy
    fi
    
    # 删除日志目录
    if [[ -d "/var/log/caddy" ]]; then
        log "删除日志目录..."
        rm -rf /var/log/caddy
    fi
    
    # 删除用户和组
    if getent passwd caddy >/dev/null; then
        log "删除系统用户..."
        userdel caddy 2>/dev/null || true
    fi
    
    if getent group caddy >/dev/null; then
        log "删除系统组..."
        groupdel caddy 2>/dev/null || true
    fi
    
    # 删除其他可能的文件
    log "清理其他文件..."
    rm -f /root/caddy_info.txt 2>/dev/null || true
    rm -f /usr/local/bin/caddy 2>/dev/null || true
    
    # 清理自动更新组件
    log "清理自动更新组件..."
    # 停止并禁用自动更新定时器
    systemctl stop caddy-auto-update.timer 2>/dev/null || true
    systemctl disable caddy-auto-update.timer 2>/dev/null || true
    
    # 删除自动更新服务和定时器文件
    if [[ -f "/etc/systemd/system/caddy-auto-update.service" ]]; then
        rm -f /etc/systemd/system/caddy-auto-update.service
    fi
    if [[ -f "/etc/systemd/system/caddy-auto-update.timer" ]]; then
        rm -f /etc/systemd/system/caddy-auto-update.timer
    fi
    
    # 删除自动更新脚本
    if [[ -f "/usr/local/bin/caddy-auto-updater.sh" ]]; then
        rm -f /usr/local/bin/caddy-auto-updater.sh
    fi
    
    # 删除更新日志文件
    if [[ -f "/var/log/caddy-auto-update.log" ]]; then
        rm -f /var/log/caddy-auto-update.log
    fi
    if [[ -f "/var/log/caddy-update-error.log" ]]; then
        rm -f /var/log/caddy-update-error.log
    fi
    
    # 重新加载 systemd
    systemctl daemon-reload 2>/dev/null || true
    
    # 清理防火墙规则（如果使用ufw）
    if command -v ufw >/dev/null 2>&1; then
        log "清理防火墙规则..."
        ufw --force delete allow 443/tcp 2>/dev/null || true
        ufw --force delete allow 80/tcp 2>/dev/null || true
    fi
    
    echo
    echo "================================================================"
    log "${green}✅ 天神之眼卸载完成！${none}"
    echo
    echo -e "${yellow}清理完成的项目:${none}"
    echo "• 系统服务 (caddy.service)"
    echo "• 可执行文件 (/usr/bin/caddy)"
    echo "• 配置目录 (/etc/caddy)"
    echo "• 数据目录 (/var/lib/caddy)"
    echo "• 系统用户和组 (caddy)"
    echo "• 自动更新服务和定时器 (caddy-auto-update.*)"
    echo "• 自动更新脚本 (/usr/local/bin/caddy-auto-updater.sh)"
    echo "• 更新日志 (/var/log/caddy-auto-update.log)"
    echo
    echo -e "${cyan}备份文件保留在 /root/ 目录中，以 caddy_data_backup_ 开头${none}"
    echo "================================================================"
}

# 检查是否以root权限运行
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 确认卸载
echo -e "${red}天神之眼卸载工具${none}"
echo "================================================================"
echo -e "${yellow}⚠️  警告: 此操作将完全卸载天神之眼！${none}"
echo
echo "卸载将执行以下操作:"
echo "• 停止并删除天神之眼服务"
echo "• 删除所有程序文件和配置"
echo "• 删除系统用户和组"
echo "• 自动备份当前配置到 /root/"
echo
echo "================================================================"
echo

read -p "$(echo -e "确定要卸载天神之眼吗? (${red}y${none}/${green}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${green}卸载已取消${none}"
    exit 0
fi

echo
echo -e "${red}最后确认: 这将删除所有天神之眼相关文件！${none}"
read -p "$(echo -e "请再次确认 (输入 ${red}YES${none} 继续): ")" final_confirm
if [[ "$final_confirm" != "YES" ]]; then
    echo -e "${green}卸载已取消${none}"
    exit 0
fi

# 开始卸载
uninstall_caddy