#!/bin/bash

# 天神之眼数据恢复脚本

# 强制设置终端支持颜色
export TERM=xterm-256color

# 颜色定义
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
none='\033[0m'

# 日志函数
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 错误处理
error_exit() {
    log "${red}❌ $1${none}"
    exit 1
}

# 暂停函数
pause() {
    read -rsp "$(echo -e "按${cyan}Enter${none}键继续...或按${cyan}Ctrl+C${none}取消")" -d $'\n'
    echo
}

# 列出可用的备份文件
list_backup_files() {
    local backup_files=()
    local count=0

    # 调试信息
    log "正在搜索备份文件: /root/caddy_data_backup_*.zip" >&2

    # 使用 find 命令查找备份文件（更可靠）
    while IFS= read -r -d '' file; do
        if [[ -f "$file" ]]; then
            backup_files+=("$file")
            count=$((count + 1))
            log "找到备份文件: $file" >&2
        fi
    done < <(find /root -maxdepth 1 -name "caddy_data_backup_*.zip" -type f -print0 2>/dev/null)

    # 如果 find 没找到，尝试传统方法
    if [[ $count -eq 0 ]]; then
        log "使用传统方法搜索..." >&2
        shopt -s nullglob  # 启用 nullglob，避免通配符不匹配时的问题
        local files=(/root/caddy_data_backup_*.zip)
        shopt -u nullglob  # 关闭 nullglob

        for file in "${files[@]}"; do
            if [[ -f "$file" ]]; then
                backup_files+=("$file")
                count=$((count + 1))
                log "找到备份文件: $file" >&2
            fi
        done
    fi

    if [[ $count -eq 0 ]]; then
        error_exit "未找到任何备份文件 (caddy_data_backup_*.zip)"
    fi

    echo -e "${yellow}找到 $count 个备份文件:${none}" >&2
    echo "================================================================" >&2

    # 按时间排序（最新的在前）
    IFS=$'\n' backup_files=($(sort -r <<<"${backup_files[*]}"))
    unset IFS

    for i in "${!backup_files[@]}"; do
        local file="${backup_files[$i]}"
        local basename=$(basename "$file")
        local file_size=$(du -h "$file" 2>/dev/null | cut -f1 || echo "未知")
        local file_date=$(stat -c %y "$file" 2>/dev/null | cut -d' ' -f1,2 | cut -d'.' -f1 || echo "未知")

        printf "%2d) %s\n" $((i + 1)) "$basename" >&2
        printf "    大小: %s, 创建时间: %s\n" "$file_size" "$file_date" >&2
        echo >&2
    done

    echo "================================================================" >&2

    # 让用户选择
    while true; do
        read -p "$(echo -e "请选择要恢复的备份文件 (1-$count): ")" choice

        if [[ "$choice" =~ ^[0-9]+$ ]] && [[ $choice -ge 1 ]] && [[ $choice -le $count ]]; then
            selected_file="${backup_files[$((choice - 1))]}"
            break
        else
            echo -e "${red}无效选择，请输入 1-$count 之间的数字${none}" >&2
        fi
    done

    echo "$selected_file"
}

# 主恢复函数
restore_caddy_data() {
    echo -e "${yellow}🔄 开始恢复天神之眼数据...${none}"
    echo "================================================================"
    
    # 列出并选择备份文件
    local backup_file=$(list_backup_files)
    local basename=$(basename "$backup_file")
    
    echo -e "选择的备份文件: ${cyan}$basename${none}"
    echo
    
    # 最终确认
    echo -e "${yellow}⚠️  警告: 恢复操作将覆盖当前的所有配置！${none}"
    read -p "$(echo -e "确定要恢复此备份吗? (${green}y${none}/${red}N${none}): ")" final_confirm
    if [[ "$final_confirm" != "y" && "$final_confirm" != "Y" ]]; then
        echo -e "${yellow}恢复已取消${none}"
        exit 0
    fi
    
    # 检查unzip命令是否可用
    if ! command -v unzip >/dev/null 2>&1; then
        log "安装unzip工具..."
        apt update -qq && apt install -y unzip || error_exit "无法安装unzip工具"
    fi
    
    # 停止caddy服务
    log "停止天神之眼服务..."
    systemctl stop caddy 2>/dev/null || true
    
    # 备份当前配置（以防恢复失败）
    if [[ -d "/etc/caddy" ]]; then
        local current_backup="/tmp/caddy_current_backup_$(date +%s).zip"
        log "备份当前配置到: $current_backup"
        cd /etc && zip -r "$current_backup" caddy/ >/dev/null 2>&1 || true
    fi
    
    # 删除当前配置目录
    log "清理当前配置..."
    rm -rf /etc/caddy
    
    # 创建目标目录
    mkdir -p /etc
    
    # 恢复备份
    log "正在恢复备份数据..."
    cd /etc
    
    if unzip -q "$backup_file"; then
        log "✅ 数据恢复成功"
        
        # 设置正确的权限
        log "设置文件权限..."
        chown -R caddy:caddy /etc/caddy/ 2>/dev/null || true
        chmod -R 755 /etc/caddy/ 2>/dev/null || true
        
        # 重启caddy服务
        log "重启天神之眼服务..."
        systemctl start caddy
        
        # 等待服务启动
        sleep 3
        
        # 检查服务状态
        if systemctl is-active --quiet caddy; then
            log "✅ 天神之眼服务启动成功"
        else
            log "${yellow}⚠️  服务启动异常，请检查配置${none}"
            log "查看服务状态: systemctl status caddy"
            log "查看日志: journalctl -u caddy -f"
        fi
        
        # 显示恢复的内容概览
        echo
        echo -e "${yellow}恢复内容概览:${none}"
        echo "----------------------------------------------------------------"
        find /etc/caddy -type f | head -10
        local total_files=$(find /etc/caddy -type f | wc -l)
        if [[ $total_files -gt 10 ]]; then
            echo "... 还有 $((total_files - 10)) 个文件"
        fi
        echo "----------------------------------------------------------------"
        echo -e "总计恢复: ${cyan}$total_files${none} 个文件"
        
    else
        error_exit "恢复失败，请检查备份文件是否损坏"
    fi
    
    echo
    echo "================================================================"
    log "${green}🎉 数据恢复完成！${none}"
    echo -e "恢复的备份: ${cyan}$basename${none}"
    echo "================================================================"
}

# 检查是否以root权限运行
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}此脚本需要root权限运行${none}"
    echo "请使用: sudo $0"
    exit 1
fi

# 确认恢复
echo -e "${green}天神之眼数据恢复工具${none}"
echo "================================================================"
echo "此脚本将从备份文件恢复天神之眼配置数据"
echo "⚠️  注意: 恢复操作将覆盖当前所有配置！"
echo "================================================================"
echo

read -p "$(echo -e "是否继续恢复? (${green}y${none}/${red}N${none}): ")" confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${yellow}恢复已取消${none}"
    exit 0
fi

# 开始恢复
restore_caddy_data